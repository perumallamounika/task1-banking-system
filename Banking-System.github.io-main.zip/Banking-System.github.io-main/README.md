
<h1><hr>The Sparks Foundation </h1><br>
<b><hr>Internship Project : Basic Banking System 💻<br></b>
Create a simple dynamic website which has the following specs.<br><br>

Start with creating a dummy data in database for upto 10 customers.Customers table will have basic fields such as name, email, current balance etc. Transfers table will record all transfers happened.<br><br>


Flow: Home Page > View all Customers > Select and View one Customer > Transfer Money > Select customer to transfer to > View all Customers.<br><br>

No Login Page. No User Creation. Only transfer of money between multiple users.<br><br>

Host the website at 000webhost. github.io, heroku app or any other free hosting provider. Check in code in gitlab.
<br><br>
Github Link :https://github.com/SudhaDidwani/Banking-System.github.io.git <br>
website Link: https://github.com/SudhaDidwani/Banking-System.github.io<br>
Linkedin Link:- https://www.linkedin.com/in/sudha-didwani-069403233<br>
